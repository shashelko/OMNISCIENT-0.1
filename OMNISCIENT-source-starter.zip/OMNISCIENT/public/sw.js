const CACHE='omniscient-v2';
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(['/','/index.html']))));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener('fetch',e=>{
 if(e.request.method!=='GET') return;
 const url=new URL(e.request.url);
 if(url.origin!==self.location.origin) return;
 e.respondWith(caches.match(e.request).then(async cached=>{
  if(cached) return cached;
  try { const response=await fetch(e.request); if(response.ok){const c=await caches.open(CACHE);c.put(e.request,response.clone());} return response; }
  catch { return e.request.mode==='navigate' ? (await caches.match('/index.html')) : new Response('',{status:503}); }
 }));
});